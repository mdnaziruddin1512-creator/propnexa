# PropNexa MVP

A scalable starter for PropNexa — Global Real Estate.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL`.
4. Run `npx prisma generate`.
5. Create the database schema with `npx prisma migrate dev --name init`.
6. Run `npm run dev`.
7. Open http://localhost:3000

## Current scope
- Premium responsive public homepage
- Property categories: Land, Building, Flat
- Search UI (front-end demo)
- Required Documents section
- Transaction-oriented structure
- PostgreSQL Prisma schema for users, properties and documents

## Production work still required
- Secure authentication and role-based authorization
- Real property search/API
- Seller property submission
- Document upload to private object storage
- Verification workflow
- Buyer/seller dashboards
- Offers and transaction module
- Payments/accounting integration
- Admin dashboard
- Audit logs
- Email/SMS/notification service
- Security hardening, backups, monitoring
- Legal documents reviewed for Bangladesh operations

Demo property cards are not real listings.
