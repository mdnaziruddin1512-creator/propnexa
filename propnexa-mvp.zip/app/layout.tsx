import "./globals.css";

export const metadata = {
  title: "PropNexa | Global Real Estate",
  description: "Your Property, Our Commitment."
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}