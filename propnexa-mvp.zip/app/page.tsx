const properties = [
  {code:"PN-CTG-00001", type:"Land", title:"Premium Residential Land", location:"Chattogram", size:"5 Katha", price:"৳50,00,000"},
  {code:"PN-CTG-00002", type:"Flat", title:"Modern City Apartment", location:"Chattogram", size:"1,450 sq ft", price:"৳95,00,000"},
  {code:"PN-DHK-00003", type:"Building", title:"Commercial Building", location:"Dhaka", size:"6,200 sq ft", price:"৳4,80,00,000"}
];

export default function Home(){
  return <main>
    <header className="nav">
      <div className="brand"><span>PN</span><div><b>PropNexa</b><small>GLOBAL REAL ESTATE</small></div></div>
      <nav><a href="#properties">Properties</a><a href="#how">How it works</a><a href="#docs">Documents</a><a href="#contact">Contact</a></nav>
      <button className="outline">List Property</button>
    </header>

    <section className="hero">
      <div className="heroText">
        <p className="eyebrow">GLOBAL REAL ESTATE</p>
        <h1>Your Property,<br/><em>Our Commitment.</em></h1>
        <p className="lead">A modern platform for discovering, reviewing and transacting land, buildings and flats with PropNexa.</p>
        <div className="search">
          <input placeholder="Search by location or property..." />
          <select><option>All types</option><option>Land</option><option>Building</option><option>Flat</option></select>
          <button>Search</button>
        </div>
      </div>
      <div className="heroCard">
        <div className="globe">PN</div>
        <strong>Property, connected.</strong>
        <span>Land • Building • Flat</span>
      </div>
    </section>

    <section id="properties" className="section">
      <div className="sectionHead"><div><p className="eyebrow">FEATURED</p><h2>Explore properties</h2></div><button className="outline">View all</button></div>
      <div className="grid">{properties.map(p=><article className="property" key={p.code}>
        <div className="photo"><span>{p.type}</span><b>PROP NEXA</b></div>
        <div className="propertyBody"><small>{p.code} · {p.location}</small><h3>{p.title}</h3><p>{p.size}</p><strong>{p.price}</strong></div>
      </article>)}</div>
      <p className="demo">Demo listings — replace with real property data after backend setup.</p>
    </section>

    <section id="how" className="dark section">
      <p className="eyebrow">HOW IT WORKS</p><h2>A platform built around the transaction.</h2>
      <div className="steps">{["Search","Review documents","Work with PropNexa","Complete transaction"].map((s,i)=><div className="step" key={s}><b>0{i+1}</b><h3>{s}</h3><p>Structured workflow with clear status and responsible handling.</p></div>)}</div>
    </section>

    <section id="docs" className="section">
      <p className="eyebrow">DOCUMENTS</p><h2>Required Documents</h2>
      <div className="docgrid">{["Land","Building","Flat"].map(x=><div className="doc" key={x}><h3>{x}</h3><p>Document checklist, submission and verification status.</p><div><span>Submitted</span><span>Under Review</span><span>Verified</span></div></div>)}</div>
    </section>

    <section id="contact" className="cta"><div><p className="eyebrow">PROPNEXA</p><h2>Build your property journey with confidence.</h2><p>Start with the MVP today and connect a secure backend, database and admin system as the platform grows.</p></div><button>Submit a Property</button></section>

    <footer><div className="brand"><span>PN</span><div><b>PropNexa</b><small>GLOBAL REAL ESTATE</small></div></div><p>Your Property, Our Commitment.</p></footer>
  </main>
}